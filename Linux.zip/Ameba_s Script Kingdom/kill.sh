: << XD

script qu ete pida el nombre del proceso al que quieres mandar una señal, despues te muestra:

señal a mandar

1- SIGSTOP
2- SIGKILL
3- SIGTERM
4- SIGUP

debes mandar la señal seleccionada al proceso

XD

#! /bin/bash

clear

read -p "Introduce un nombre de un proceso: " pname

proc=`ps --no-headers -o pid -C $pname`

echo "Introduce una opción:

1- SIGSTOP
2- SIGKILL
3- SIGTERM
4- SIGUP
"

read -p "¿Opción seleccionada? " op

case $op in

1) echo "Se ha seleccionado SIGSTOP"
kill -SIGSTOP $proc
;;
2) echo "Se ha seleccionado SIGKILL"
kill -SIGKILL $proc
;;
3) echo "Se ha seleccionado SIGTERM"
kill -SIGTERM $proc
;;
4) echo "Se ha seleccionado SIGUP"
kill -SIGUP $proc
;;
*) echo "Opción incorrecta"
;;
esac

