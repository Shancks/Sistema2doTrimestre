: <<XD

GESTION DE CUENTAS

- crear una cuenta nueva
- modificiar una cuenta existente
- borrar cuenta existente
4. cambiar contraseña cuenta existente

en opcion 1 pedir: comentarios, shell uid, g ppal, grupos
en opcione 2 pedir: ¿qué quieres modificar?
en opcion 3 pedir si quieres borrar directorio personal
en opcion 4 pedir pass y reintroducir (tienen que coincidir)

XD

#! /bin/bash

clear

uid=`cat /etc/passwd | grep -e "root" | cut -d ":" -f 3`

if test $uid = "$UID"
then

	echo -e "GESTIÓN DE CUENTAS
	-------------------

	1. Crear una cuenta nueva
	2. Modificar datos de una cuenta existente
	3. Borrar una cuenta existente
	4. Cambiar contraseña de una cuenta existente
	5. SALIR\n"

	read -p "Selecciona una opción: " op1

	case $op1 in

	1) 	clear

		echo -e "Ha seleccionado la opción \e[93m'CREAR CUENTA NUEVA'\e[0m"

		clear

		read -p "Escriba su nombre de usuario: " name

		clear

		read -p "Escriba el nº de UID que desea asignar: " uid

		clear

		read -p "Escriba el nº o nombre de grupo que desea como grupo principal: " gppal

		clear

		read -p "¿Cuántos grupos desea añadir?: " ngrupos

		grupos=""

		for ((i=1 ; i <= ngrupos; i++))
		do
			read -p "Indica el GID del grupo $i: " gid_add

			if test $i -eq 1
			then
				grupos+="$gid_add"
			else
				grupos+=",$gid_add"
			fi
		done

		clear

		read -p "Indique un comentario para la cuenta" comment

		clear

		read -p "Indique la ruta para la Shell" shell_path

		if test `useradd -u "$uid" -g "$gppal" -G "$grupos" -c "$comment" -s "$shell_path" "$name"`
# Me cago en mi puta vida que la salida del comando no es 0
		then
			clear
			echo "Cuenta creada"

		else
			echo "Datos erroneos. La cuenta no se ha creado"

		fi

		;;

	2) "2"

	;;

	3) "3"

	;;

	4) "4"
	 
	;;

	5) 	clear

		echo "Se procederá a salir del gestor"

		sleep 1s

		clear

		echo "..."

		sleep 1s

		echo "..."

		sleep 1s

		clear

		echo "¡Adiós!"

		sleep 1s

		clear

		exit 2

		;;

	*)	clear

		echo "La opción seleccionada es incorrecta"

		;;

	esac

else

	echo -e "No tienes el poder del \e[93mroot\e[0m. Abandona las premisas"
	exit 1
fi

