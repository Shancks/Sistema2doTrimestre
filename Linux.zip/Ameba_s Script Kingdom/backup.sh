:<<XD

Script para backups con menu:

TIPO DE BACKUP
··············

1. BACKUP TOTAL
2. BACKUP INCREMENTAL
3. -- SALIR --

- Pedir un directorio sobre el que hacer backups
- Pedir directorio de destino
- Añadir la fecha en el nombre del archivo
- Añadir para los incrementales el nº de incremental hecho

XD

#! /bin/bash

clear

cat << XD

TIPO DE BACKUP
..............

1. BACKUP TOTAL
2. BACKUP INCREMENTAL
3. -- SALIR --

XD

read -p "Elige una opción: " op

case $op in

	1|2) clear
	read -p "Introduce el directorio para la copia: " directory

	if test -d "$directory"
	then
		clear
		echo "El directorio elegido es correcto"
		sleep 2s
		clear
		
		if test $op -eq 1
		then
			echo -e "Se procederá a la creación del backup total\n"

			date=`date +"%Y-%m-%d_%H-%M-%S"` # no se puede usar la opción del comando date "%T" porque se le pira la pinza con el formato y piensa que la ruta es mas larga
			name_directory=`echo "${directory##*/}"` # pendiente aprender a hacer esto con sed y con awk para usar regex
			
			# /tmp/pruebas tiene que ser un directorio que exista, lo suyo sería preguntar directorio de destino y crearlo si no existe, pero es una chorrada y me da palo
			tar -c -v -z -g /tmp/pruebas/referencia_backup_"$name_directory" -f /tmp/pruebas/backup_"$name_directory"_"$date"_total.tar.gz "$directory"

			echo -e "\nProceso de creación completado"
		else

			date=`date +"%Y-%m-%d_%H-%M-%S"`
			name_directory=`echo "${directory##*/}"`
			n_incremental=`find /tmp -type f -name "backup_"$name_directory"_*" | wc -l`

			if test $n_incremental -eq 0
			then
				echo -e "Lo sentimos. El directorio "$name_directory" no tiene backup total creado. Por favor, créelo primero"
				sleep 6s
				clear
				echo "La aplicación saldrá"
				exit 4

			else						
				echo -e "Se procederá a la creación del backup incremental\n"

				tar -c -v -z -g /tmp/pruebas/referencia_backup_"$name_directory" -f /tmp/pruebas/backup_"$name_directory"_"$date"_incremental_n"$n_incremental".tar.gz "$directory"

				echo -e "\n Proceso de creación completado"
			fi
		fi					
		
	else
		echo "El directorio es incorrecto. La aplicación saldrá"
		exit 3
	fi			

	;;

	3) clear
	echo "Ha seleccionado SALIR."
	sleep 2s
	clear
	echo "La aplicación saldrá"
	exit 1
	
	;;

	*) clear 
	echo "La opción seleccionada no es correcta".
	sleep 2s
	clear
	echo "La aplicación saldrá"
	exit 2

	;;
esac


