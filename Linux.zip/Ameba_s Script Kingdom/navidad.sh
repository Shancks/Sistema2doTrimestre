:<<XD

Se viene la Navidad, amigos.

XD

#! /bin/bash

clear

echo "¿Es Navidad?"

sleep 2

clear

sleep 2

echo "..."

sleep 2

clear

sleep 2

echo "..."

sleep 2

clear

sleep 2

current_time=`date +"%d/%m"`

if test "$current_time" = "25/12"
then

	echo "Sí."

else

	echo "No."

fi
