: << XD

XD

#! /bin/bash
clear

echo "este es el valor del primer parametro $1"
echo "este es el valor del segundo parametro $2"
echo "este es el valor del tercer parametro $3"
echo "este es el valor del cuarto parametro $4"
echo "este es el valor del quinto parametro $5"
echo "este es el valor del sexto parametro $6"
echo "este es el valor del séptimo parametro $7"
echo "este es el valor del octavo parametro $8"
echo "este es el valor del noveno parametro $9"

echo "---"
echo -e " el array de parametros es $*"
echo -e " el numero de parametros: $#"

shift

echo "este es el valor del primer parametro $1"
echo "este es el valor del segundo parametro $2"
echo "este es el valor del tercer parametro $3"
echo "este es el valor del cuarto parametro $4"
echo "este es el valor del quinto parametro $5"
echo "este es el valor del sexto parametro $6"
echo "este es el valor del séptimo parametro $7"
echo "este es el valor del octavo parametro $8"
echo "este es el valor del noveno parametro $9"
