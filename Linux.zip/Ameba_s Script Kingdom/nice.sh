: << XD

scccccript   que te pida:

- el nombre de la aplicacion a cambiabr la prioridad
-el valor de la bondad (la bonda comprobar qu eesta en tre 19 y 20
si quieres ejecutrarla desde el principio con esa bondad yoo si se esta ya ejcutando cambairse

lanzarla za con esa bondad

cambiar la bondad el proceso en jecuciuon opcion

XD

clear

read -p "Dime una aplicacion a ejecutar o a subir prioridad" pname
pid=`pidof $pname`

	if $pid

	then
	ni=`ps --no-headers -o ni -C $pname`

		if test	$ni -lt -19 -o $ni -gt 20

		then
		echo "El valor no está entre -19 y 20. El script finalizará"
		exit 0
		else
		read -p "¿Quieres cambiar la bondad? (S/N)" op1
		
			case $op1 in
			
			S)read -p "Introduce valor: " ni_value		
			renice -n $ni_value -p $pid
			;;
			N) echo "La bondad no se ha cambiado. El script finalizará"
			exit 0
			;;
			*) echo "Opción incorrecta. El script finalizará"
			exit 0
			;;

			esac
		fi		 

	else

	echo "Ejecutamos la aplicación $pname"
	read -p "¿Quieres cambiar la bondad del proceso que se ejecuta? (S/N)" op2

		case $op2 in

		S) read -p "Introduce la bondad que quieres introducir: " ni_value2
		exec $pname
		renice $ni_value2 -p $pid
		;;
		N) echo "El proceso se ha ejecutado con la bondad estándar"
		exec $pname
		;;
		*) echo "Opción incorrecta. El script finalizará"
		exit 0
		;;

		esac

	fi


