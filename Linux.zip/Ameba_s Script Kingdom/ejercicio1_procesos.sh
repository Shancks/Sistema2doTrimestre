: <<EOF

Script que te pida el nombre de un usuario. TIenes que mostrar los procesos de ese usuario.
Estas opciones:
	- pid
	- ppid
	- prioridad
	- bondad
	- uso de memoria
	- uso de cpu
	- tiempo de ejecucion
	- comando

EOF

#! /bin/bash

clear

read -p "Introduce un nombre de usuario: " user

#usando el comando passwd en lugar de ir a leer el contenido del fichero, solo vale con el usuario activo

user2=`passwd -S | cut -d" " -f1`

if [[ $user2 = $user ]]
then

echo -e "VAMOS A MOSTRAR LOS PROCESOS DE: $user2"

ps -u $user -o pid,ppid,pri,ni,pmem,cputime,state,cmd,etime

else

echo "El usuario logueado no es igual al usuario introducido"

fi

#sin usar el comando passwd

cd /etc

user3=`cat passwd | grep $user | cut -d: -f1`

if [ $user3 = $user ]
then

echo -e "VAMOS A MOSTRAR LOS PROCESOS DE: $user"

ps -u $user -o pid,ppid,pri,ni,pmem,cputime,state,cmd,etime

else

echo "El usuario buscado no se encuentra"

fi









