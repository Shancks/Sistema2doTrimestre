: <<XD

XD

echo "Bienvenido a Linux, subnormal"
