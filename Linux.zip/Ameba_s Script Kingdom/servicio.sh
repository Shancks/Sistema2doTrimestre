: << XD

XD

#!/bin/bash

while true
do

	case "$1" in
		start) #lanzo servicio con parametros
		# $0 nombre del script
		/usr/bin/servicio_echo.sh & 
		;;
		stop) kill -s SIGTERM $0
		;;
		status) $
		;;
		*) echo "Uso: $0 start|stop|status"
		;;
	esac
done
		
		
