: <<XD

script control estado de un servicio
te ha de pedir el nombre de un servicio y mostrar el menu:

ADMIN SERVICIOS
----------------
1. ARRANCAR UN SERVICIO
2. PARAR UN SERVICIO
3. VER EL FICHERO DE CONFIGURACION DE UN SERVICIO
4. DEPENDENCIAS DE UN SERVICIO
5. SALIR

XD
#!/bin/bash

op=0

while test $op -ne 6
do

	clear
	
	echo -e "ADMIN SERVICIOS
		----------------
		1. ARRANCAR UN SERVICIO
		2. PARAR UN SERVICIO
		3. VER EL FICHERO DE CONFIGURACION DE UN SERVICIO
		4. DEPENDENCIAS DE UN SERVICIO
		5. VER EL ESTADO DE UN SERVIO
		6. SALIR"

read -p "Elige una opción" op
read -p "Elige el nombre de un servicio" name

case $op in
	1) systemctl start $name.service 2>/dev/null
	;;
	2) systemctl stop $name.service 
	;;
	3) systemctl cat $serv.service
	;;
	4) systemctl list-dependencies $name.service
	;;
	5) systemctl status $name.service
	;;
esac

sleep 5s

done
