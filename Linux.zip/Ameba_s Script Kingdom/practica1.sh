: <<XD

generar un servicio en systemd que escuche por el puerto 6666 y que al conectarse a el que te diga:

"BUenos días, son las..."

Ha de arrancarse en multi-user.target

XD

#!/bin/bash

hora=`date +"%T"`

echo "Buenos días, aventurero. Son las $hora" | nc -l localhost -p 6666
