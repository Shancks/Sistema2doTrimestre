:<<XD
	script del servicio de ECHO
	Cuando alguien se conecte 
XD

#!/bin/bash

if ! test -p /tmp/tuberia
then
	mkfifo /tmp/tuberia
fi

cat /tmp/tuberia | nc -l localhost -p 7777 > /tmp/tuberia
