:<<XD

hay que comprobar si eres root antes de ejecutarlo 
	(ver variables de entornos UID o USERNAME) Si no eres root mostrar mensaje de error
		y salir
	Te tien que pedir el nombre de una cuenta y te debe mostrar :
	-directorio personal:---
	-uid: ----
	-gid:---
	-shel:---
	-hashpass:--

XD

#!/bin/bash

clear

uid=`cat /etc/passwd | grep -e "root" | cut -d ":" -f 3`

if test $uid = "$UID"
then

	echo -e "\nEl poder del \e[93mroot\e[0m está conmigo\n"

	read -p "Introduce una cuenta para ver sus datos: " user

	name=`cat /etc/passwd | grep -e "$user" | cut -d ":" -f 1`

	if test "$user" = "$name"
	then	
		clear
			
		personal_dir=`cat /etc/passwd | grep -e "$user" | cut -d ":" -f 6`
		uid2=`cat /etc/passwd | grep -e "$user" | cut -d ":" -f 3`
		gid=`cat /etc/passwd | grep -e "$user" | cut -d ":" -f 4`
		shell=`cat /etc/passwd | grep -e "$user" | cut -d ":" -f 7`
		hashpass=`cat /etc/passwd | grep -e "$user" | cut -d ":" -f 2`

		echo -e "\nDatos de usuario \e[93m$user\e[0m:\n"
		echo -e "\t- UID: \e[93m$uid2\e[0m"
		echo -e "\t- GID: \e[93m$gid\e[0m"
		echo -e "\t- Directorio personal: \e[93m$personal_dir\e[0m"
		echo -e "\t- Shell: \e[93m$shell\e[0m"

		if test "$hashpass" = "x"
		then
			echo -e "\t- Password hash: no tiene hash\n"		

		else
			echo -e "\t- Password hash: \e[93m$hashpass\e[0m\n"
		fi
	
	else
		clear
		echo -e "\nEl usuario \e[93m$user\e[0m no se encuentra en la base de datos."
		exit 1
	fi

else
	echo -e "No tienes el poder del \e[93mroot\e[0m. Abandona las premisas"
	exit 2
fi
