: <<cc
	script jena
cc
#! /bin/bash
 echo "....hola compadre...."
