: <<Eof
	Script que te pida el nombre de un usuario mostrar los procesos de ese usuario
	estas opciones:
		-pid
		-ppid	
		-prioridad
		-bondad
		-estado de proceso
		-uso de memoria
		-uso de Cpu
		-tiempo de ejecucion
		-comando
Eof
#! /bin/bash
clear
