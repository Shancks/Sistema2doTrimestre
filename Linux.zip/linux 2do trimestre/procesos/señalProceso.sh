:<<EOF

	script q t pida el nombre del proceso al q quierees mandar una señal,despues te muestra:
	señal a mandar..
	1-SIGSTOP	
	2-SIGKILL
	3-SIGTERM
	4-SIGUP
	opcion_
debe mandar la señal al proceso
EOF
clear
read -p "introduce el proceso....." $pro
echo "	
	 señal a mandar...
	1-SIGSTOP	
	2-SIGKILL
	3-SIGTERM
	4-SIGUP"
read -p "introduce la señal q quieres mandar....." op

	case $op in
	1) senal=SIGSTOP
		;;
	2)  senal=SIGKILL
		;;
	3)  senal=SIGTERM
		;;
	4) senal=SIGUP
	break;
		;;
	*)
	 echo "valor introducido no valido....no sabes leer?¿?¿?"
       	exit 0;
	esac 	
echo -e "mandando la señal $senal al proceso $pro"
kill -s $senal `pidof $pro`



