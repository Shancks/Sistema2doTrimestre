#!/bin/bash
:<<EOF
script q te pida:

  - el nombre de la aplicacion a cambiar la prioridad. 
  - el valor de la bondad (comprobar q esta entre -19 y 20)
  - si quieres ejecutarla desde el principio con esa
   bondad o si se esta ya ejecutando cambiarsela:

	1. Lanzarla con esa bondad
	2. cambiar la bondad del proceso en ejecucion
EOF
clear

read -p "introduce la app a la q quieres cambiar la prioridad: " $app
read -p "introduce la prioridad q quieres darle...recuerda¡¡...debe de estar entre -19 y 20: " $pri
	
	if [$pri -lt -19 -o $pri -gt 20];
	then
	 echo "valor correcto.."
	
echo "
		1. Lanzarla con esa bondad
		2. cambiar la bondad del proceso en ejecucion"

	read -p" introduce una opcion" $op
	if test $op -eq 1
	then echo "lanzando la aplicacion $app con bondad $pri"
	nice -n $pri $app
	 ps -o pid,ppid,pri,ni,status,cmd -C $app
	elif test $op -eq 2
	then echo "cambiando la bondad de la app:app $app con bondad $pri"
	renice -n $pri -p `pidof $app`
	 ps -o pid,ppid,pri,ni,status,cmd -C $app
	else
		echo "opcion incorrecta"

echo "valor incorrecto...debe de estar ente -19 y 20"
	exit 0;
fi
fi
