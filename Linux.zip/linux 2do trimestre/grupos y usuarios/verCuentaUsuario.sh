: <<EOF
	hay q comprobar si eres root antes de ejecutarlo 
	(ver variable de entorno UID o USERNAME) si no eres
	root mostrar mensaje de error y salir...

	te tiene q pedir el nombre de una cuenta y te debe mostrar:

		- directorio personal: ......
		- uid: .....
		- gid: .....
		- shell: ....
		- hashpass: ....
EOF

#usuarioLogueado=`whoami`
#if test "$usuarioLogueado" = "root"
if test "$USERNAME" = "root"
then
	read -p "introduce nombre usuario:_" usuario

else
	echo "...no eres root, no puedes ejecutar este script..."
	exit 0
fi


















