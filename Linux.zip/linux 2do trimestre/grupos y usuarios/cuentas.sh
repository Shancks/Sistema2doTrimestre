:<<EOF
	- crear una nueva cuenta llamada: practica
comentario: "cuenta de practicas de sistemas"

uid: 9999
grupo principal: adm
grupos secundarios: users,sudo
shell: /bin/bash
password: 123456AbC
- comprobar q existe en /etc/passwd
- comprobar q existe el hash en /etc/shadow
- iniciar sesion con la cuenta en otro terminal

EOF
#! /bin/bash

	if [ `whoami` != "root" ]; then
   	 echo "No eres root...no puedes continuar con este script"
	exit 0
	else "eres root..puedes continuar..."

	echo "script con el que puedes crear cuentas de usuario"
	clear
	read -p "introduce el uid q le quieres asignar:_" uid
	clear
	read -p "introduce el nombre de la cuenta:_" nom
	clear	
	read -p "introduce el grupo principal al que pertenece:_" grupo
	clear
	read -p "introduce el grupo secundario al que pertenece:_" grus
	clear
	
	read -p "Ingrese una contraseña para $nom: " con 
	useradd -u "$uid" -g "$grupo" -G "$grus" "$nom" 
	if id -u "$nom" >/dev/null 2>&1;
	then	
	echo "$nom:$con" | chpasswd
	echo "usuario creado"
	else echo "no se ha creado el usuario"
	exit 0
fi
fi

	


