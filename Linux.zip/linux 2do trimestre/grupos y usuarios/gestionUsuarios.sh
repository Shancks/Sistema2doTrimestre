: <<EOF
	script administracion cuentas de usuario
		GESTION CUENTAS
		---------------
		1.Crear nueva cuenta	
		2.Modificar cuenta existente
		3.Borrar Cuenta existente
		4.Cambiar password cuenta existente
		5. ---salir---

	en opcion 1 pedir:  comentarios,shell,uid,grupo principal, grupos
	en opcion 2 pedir q modificar y el valor a modificar
	en opcion 3 pedir si quieres borrar o no directorio personal
	en opcion 4 te tiene q pedir la password, reintroducir la password
		(tienen q coincidir, sin usar passwd

EOF

