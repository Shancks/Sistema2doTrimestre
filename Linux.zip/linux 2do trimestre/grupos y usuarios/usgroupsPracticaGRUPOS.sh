: <<EOF
 script q genera grupos y usuarios de la practica de GRUPOS

 crear un grupo 1DAM ---> gid 5000, password grupo: DAMvesp
  añadir usuarios:  damt1, damt2, damt3 (passwords las mismas q los logins, 
					grupo ppal 1DAM, secundario: ALUMNOS)

  administrador del grupo: profeSistemas (password la misma q el login, grupo
					ppal PROFESORES)

 crear otro grupo ALUMNOS ---> gid 6000, passwrod grupo: ALUMNOSavellaneda
 añadir usuarios: damt1, damt2, damt3


EOF
clear
test $UID -ne 0 && { echo "no eres root..."; exit 0; }

echo -e "\t\t -------------------------"
echo -e "\t\t CREANDO GRUPOS..."
echo -e "\t\t -------------------------"

groupadd -g 5000 1DAM && echo "grupo 1DAM creado ok..."
echo "1DAM:DAMvesp" | chgpasswd

groupadd -g 6000 1DAM && echo "grupo ALUMNOS creado ok..."
echo "ALUMNOS:ALUMNOSavellaneda" | chgpasswd

groupadd  PROFESORES && echo "grupo PROFESORES creado ok..."

echo -e "\t\t ----------------------------------------"
echo -e "\t\t CREANDO ALUMNOS y AÑADIRLOS A GRUPOS..."
echo -e "\t\t ----------------------------------------"

for ((a=1; a<=3; a++))
 do 
	useradd -g 1DAM -G ALUMNOS damt$a && echo "usuario damt$a creado ok..."
	echo "damt$a:damt$a" | chpasswd	
 done

useradd -g PROFESORES -G 1DAM profeSistemas && echo "usuario profeSistemas creado ok.."
gpasswd -A profeSistemas 1DAM  && echo "y ya es ADMIN del grupo 1DAM"






