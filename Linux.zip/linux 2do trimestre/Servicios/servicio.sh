:<<EOF


		1)Que me pida nombre de un usuario mostrar de los procesos de ese usuariuo estas opciones
		: pid
		ppid
		prioridad
		bondad
		estado del proceso
		uso de memoria 
		uso de cpu 	
		tiempo de ejecucion
		comando
	2) comprobar si ese usuario existe en el sistema, si no exixiste acabar el script con mensaje fichero de usuario : /etc/passwd

EOF

read -p "introduce un nombre de usuario:" usu
		echo "vamos a comprobar si existe el usuario..."
	if id -u "$usu" >/dev/null 2>&1; then
		echo " enhorabuena...el usuario existe"
		p= ps -u "$usu" -o pri,ppid,time,pri,ni,stat,rss,vsz		

	else "ohhhh.......el usuario no existe"	

fi
