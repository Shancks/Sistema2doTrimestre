#!/bin/bash
:<<EOF
	script control estado de un servicio por systemd
	te ha de pedir el nombre de un servicio y mostrar el menu:

		ADMIN SERVICIOS
		---------------
		1.Arrancar un servicio
		2.Parar un servicio
		3.Ver el fichero de configuracion de un servicio
		4.Ver Dependencias de un servicio
		5.Ver el ESTADO de un servicio
		6. ---SALIR---
		
EOF
clear
read -p "introduzca el nombre de un servicio....." $ser

	echo "

		ADMIN SERVICIOS
		---------------
		1.Arrancar un servicio
		2.Parar un servicio
		3.Ver el fichero de configuracion de un servicio
		4.Ver Dependencias de un servicio
		5.Ver el ESTADO de un servicio
		6. ---SALIR---"
		
read -p "introduzca una opcion:_" $op
case $op in 
	1) systemctl start$ser.service;;
	2) systemctl stop$ser.service;;
	3) cat $ser.service;;
	4) systemctl list-dependencies $ser.service
	5) systemctl status $ser.service

esac
