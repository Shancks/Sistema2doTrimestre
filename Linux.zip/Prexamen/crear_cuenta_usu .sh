<<EOF
	
	Crear una cuenta 
		llamada : Practica
		Comentario " Cuenta de practicas de sistemas
		uid 9999	
		grupo principal adm
		grupo secundadio  users, sudo
		shell /bin/bash
		password 123456789ABV
	Comprobar que existe en /etc/passwd
	Comprobar que existe el hash en  /etc/passwd
	iniciar sesion creada en otro terminal
EOF

		
	useradd -m -u 9999 -g adm -G sudo,users -s /bin/bash  Practica
	
	echo "Practica:123456ABC"| chpasswd

	grep -e "^Practica:" /etc/passwd
	echo "aqui sale el usuario creado"
		
	grep -e "^Practica:x" /etc/shadow 
	echo " aqui se ve el hash"

	sudo login Practica
	


