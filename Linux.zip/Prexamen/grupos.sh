<<EOF
		Crear un grupo 1DAW cpn gid 5000 
					password DAWVesp
						
		Añadir usuarios  daw1,daw2,daw3,password su nombre Grupo principal 1DAW y secundario Alumnos

		añadir un administrador del grupo profesistemas password su numbre grupo principal profesores 
		
		useradd     ------> añade un usuario
		groupadd    ------> añade un grupo
		usermod     ------> hace camios a un user
		groupmod    ------> hace cambios en un grupo
		userdel     ------> borra un user
		groupdel    ------> borra un grupo
		gpasswd     ------> añade un usuario a un grupo
		groups _nombre_usu_ - - - > ves a que grupo pertene un usuario	
		chpasswd    ------> cambia la contra a un usu
		echo " nombre usu:contraseña" | chpasswd - - - > pone la contrañeña a un user
		chgpasswd   ------> cambia la contra de un grupo
		echo " nombre gru:contraseña" | chgpasswd - - -> pone la contra a un gruop 
		newgrp      ------> cambia la guid de un grupo
		-g nombre   ------> grupo principal
		-G nombre   ------> grupos secundarios
		-r nombre   ------> crea un nuevo grupo del sistema
		-d /ruta/   ------> Donde se crea el direcotrio
		-c "     "  ------> Crea un comentario para un usuario

		chage cambia el dia que necesitas cambiar la contra 
			-M es el dia maximo que necesitas para cambiar -M 90 quiere decir que en 90 dias la tienes que cambiar
			-d 0 Es para que al siguiente inicio de sesion te obligue a cambiar
		
		
		

EOF


		groupadd -g 5000 1DAW
		echo "1DAW:1DAW"|chgpasswd
		groupadd -g 6000 alumnos
		echo "alumnos:alumnosavellaneda"|chgpasswd
		groupadd -g 6020 profesores
		echo "profesores:profe"|chgpasswd

		useradd -m -u 1002 -g 1DAW -G alumnos daw1
			echo "daw1:daw1"|chpasswd

		useradd -m -u 1021 -g 1DAW -G alumnos daw2
			echo "daw2:daw3"|chpasswd

		useradd -m -u 800 -g profesores -G alumnos  profesistemas
			gpasswd -A profesistemas alumnos
			echo " profesistemas:profasddd"|chpasswd
		
