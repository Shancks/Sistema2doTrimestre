.<<EOF

	1º Lanzar la calculadora (gnome-calculator) con bondad positiva(baja prioridad ) 20 a 0 y ponerlo en bacground nada mas lanzarlo

	2º Comprobar con el job
	
	3º pasarlo a primer plano con fg
	
	4º pulsamos control z

	5ºcomprobar con job que esta detenido

	6º volver a mandar en segundo plano con bg

	7º volver a pasar a 1º plano con fg
	
	8 volver  aparar
	
	9 comprobar que no existe un job
EOF

			nice -n 10 gnome-calculator &
			jobs
			fg %1
			pulsamos control z
			jobs
			bg %1
			fg %1
			pulsamos control c
			jobs
				
