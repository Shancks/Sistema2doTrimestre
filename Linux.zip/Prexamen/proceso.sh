.<<EOF


		1)Que me pida nombre de un usuario mostrar de los procesos de ese usuariuo estas opciones
		: pid
		ppid
		prioridad
		bondad
	estado del proceso
	uso de memoria 
	uso de cpu 	
	tiempo de ejecucion
	comando
	2) comprobar si ese usuario existe en el sistema, si no exixiste acabar el script con mensaje fichero de usuario : /etc/passwd

		pri= prioridad
		cmd= comandos
		ni= bondad
		rss=Tamaño de memoria real
		vsz= Tamaño de memoria virtual
		pid= id del proceso
		ppid=id del padre del proceso
		time=tiempo que lleva la ejecucion
		STAT= estado del proceso

EOF

		read -p "Dime el usuario que quieres ver" nombre
	if id -u "$nombre" > /dev/null 2>&1;
	then
		echo "usuario existe"
		p= ps -u $nombre -o pid,ppid,time,pri,cmd,ni,stat,rss,vsz
		echo "$p"
	else
		echo "no existe el cafre"
	fi 
