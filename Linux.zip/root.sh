:<<EOF
	
	hay que comprobar si eres root antes de ejecutarlo 
	(ver variables de entornos UID o USERNAME) Si no eres root mostrar mensaje de error
		y salir
	Te tien que pedir el nombre de una cuenta y te debe mostrar :
	-directorio personal:---
	-uid: ----
	-gid:---
	-shel:---
	-hashpass:--


EOF
