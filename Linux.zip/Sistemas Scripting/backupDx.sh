#!/bin/bash
logger -p auth.err -t miscript ".....ejecutandose script tarea ANACRON....."
